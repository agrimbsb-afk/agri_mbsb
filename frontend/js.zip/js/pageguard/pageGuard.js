// js/pageGuard.js

const API =

location.hostname === '127.0.0.1' ||
location.hostname === 'localhost'

?

'http://localhost:3000'

:

'https://agri-mbsb.onrender.com';

(async()=>{

    const token =
    localStorage.getItem(
        "token"
    );

    if(!token){

        localStorage.clear();

        window.location.replace(
            "login.html"
        );

        return;

    }

    try{

        const res =
        await fetch(

            API +
            "/api/auth/validate",

            {

                headers:{

                    Authorization:
                    "Bearer " +
                    token

                }

            }

        );

        if(!res.ok){

            throw new Error();

        }

    }
    catch(err){

        localStorage.clear();

        window.location.replace(
            "login.html"
        );

    }

})();